package operations;

public abstract class SuperAdminOperation {
}
