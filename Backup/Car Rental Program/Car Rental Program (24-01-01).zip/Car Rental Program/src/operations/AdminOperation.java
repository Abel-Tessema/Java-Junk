package operations;

public abstract class AdminOperation {
}
