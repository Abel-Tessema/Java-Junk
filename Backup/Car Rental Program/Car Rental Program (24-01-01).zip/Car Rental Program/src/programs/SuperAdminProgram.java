package programs;

public abstract class SuperAdminProgram {
    public static void main(String[] args) {

    }
}
