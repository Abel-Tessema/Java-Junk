package decision_trees;

public abstract class AdminDecisionTree {
}
