package decision_trees;

public abstract class SuperAdminDecisionTree {
}
