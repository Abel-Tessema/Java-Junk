package menus;

public abstract class SuperAdminMenu {
}
