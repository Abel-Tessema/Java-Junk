package menus;

public abstract class AdminMenu {
}
