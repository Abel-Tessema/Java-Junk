package screens;

import services.CarService;
import utility.Console;

public class CarYearScreen {
    private final CarService carService = new CarService();
    private final UserScreen userScreen = new UserScreen();
    public void display() {
        System.out.println();
        System.out.println("... > List with Filter > Year");
        System.out.println("Choose one of these available car years as a filter:");
        carService.listAllCarYears();

        int carYearChoice = (int) Console.readNumber("Choice", 1, carService.getCarYears().size());
        String carYear = carService.getCarYears().get(carYearChoice - 1);

        carService.listCarsByType(carYear);

        Console.continueOnEnter();
        userScreen.display();
    }
}
