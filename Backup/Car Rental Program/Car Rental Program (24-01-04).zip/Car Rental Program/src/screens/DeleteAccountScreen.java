package screens;

public class DeleteAccountScreen {
    public void display() {}
}
