package screens;

public class BookCarScreen {
    public void display() {}
}
