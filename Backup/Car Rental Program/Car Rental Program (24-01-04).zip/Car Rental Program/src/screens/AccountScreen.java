package screens;

import utility.Console;

public class AccountScreen {
    private final ChangeNameScreen changeNameScreen = new ChangeNameScreen();
    private final ChangePhoneNumberScreen changePhoneNumberScreen = new ChangePhoneNumberScreen();
    private final ChangeEmailScreen changeEmailScreen = new ChangeEmailScreen();
    private final ChangePasswordScreen changePasswordScreen = new ChangePasswordScreen();
    private final DeleteAccountScreen deleteAccountScreen = new DeleteAccountScreen();
    private final UserScreen userScreen = new UserScreen();
    public void display() {
        System.out.println();
        System.out.println("... > User Main Menu > Modify Account");
        System.out.println("What would you like to do?");
        System.out.println("1) Change your name");
        System.out.println("2) Change your phone number");
        System.out.println("3) Change your email address");
        System.out.println("4) Change your password");
        System.out.println("5) Delete your account");
        System.out.println("6) Go back");

        int modifyAccountChoice = (int) Console.readNumber("Choice", 1, 6);

        switch (modifyAccountChoice) {
            case 1: changeNameScreen.display(); break;
            case 2: changePhoneNumberScreen.display(); break;
            case 3: changeEmailScreen.display(); break;
            case 4: changePasswordScreen.display(); break;
            case 5: deleteAccountScreen.display(); break;
            case 6: userScreen.display(); break;
        }
    }
}
