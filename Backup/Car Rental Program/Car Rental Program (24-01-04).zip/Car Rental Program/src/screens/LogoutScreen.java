package screens;

public class LogoutScreen {
    public void display() {}
}
