package screens;

import operations.UserOperation;
import services.UserService;
import utility.Console;
import utility.Patterns;

public class ChangeNameScreen {
    private final UserService userService = new UserService();

    public void display() {
        System.out.println();
        System.out.println("... > Edit Account > Name");
        System.out.println("Your previous name is: " + userService.getUser().getName() + ".");
        String newName = Console.readText("Enter your new full name", Patterns.namePattern, "Please enter your full name with the correct format (e.g. John Doe).");
        while (true) {
            String password = Console.readText("Enter your password", Patterns.noPattern, "Too many characters. Please try again.");
            if (password.equals(userService.getUser().getPassword())) {
                userService.getUser().setName(newName);
                // ToDo: Write updated user into file
                break;
            }
            System.out.println("Incorrect password. Please try again.");
        }

    }
}
