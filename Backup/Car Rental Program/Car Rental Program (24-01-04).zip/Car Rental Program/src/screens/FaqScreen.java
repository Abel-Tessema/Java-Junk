package screens;

public class FaqScreen {
    public void display() {}
}
