package screens;

import operations.UserOperation;
import services.UserService;
import utility.Console;
import utility.Patterns;

public class ChangeEmailScreen {
    private final UserService userService = new UserService();

    public void display() {
        System.out.println();
        System.out.println("... > Edit Account > Email Address");
        System.out.println("Your previous email address is: " + userService.getUser().getEmail() + ".");
        String newEmail = Console.readText("Enter your new email address", Patterns.emailPattern, "Please enter your email address with the correct format (e.g. janedoe123@gmail.com).");
        while (true) {
            String password = Console.readText("Enter your password", Patterns.noPattern, "Too many characters. Please try again.");
            if (password.equals(userService.getUser().getPassword())) {
                userService.getUser().setEmail(newEmail);
                // ToDo: Write updated user into file
                break;
            }
            System.out.println("Incorrect password. Please try again.");
        }
    }
}
