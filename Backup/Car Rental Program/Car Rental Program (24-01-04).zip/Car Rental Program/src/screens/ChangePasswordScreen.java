package screens;

public class ChangePasswordScreen {
    public void display() {

    }
}
