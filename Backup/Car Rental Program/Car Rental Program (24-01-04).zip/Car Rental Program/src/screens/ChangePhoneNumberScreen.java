package screens;

public class ChangePhoneNumberScreen {
    public void display() {}
}
