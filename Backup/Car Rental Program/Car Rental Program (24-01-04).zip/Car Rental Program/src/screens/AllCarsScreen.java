package screens;

import services.CarService;
import utility.Console;

public class AllCarsScreen {
    private final CarService carService = new CarService();
    private final UserScreen userScreen = new UserScreen();
    public void display() {
        System.out.println();
        System.out.println("... > User Main Menu > List All Cars");
        carService.listAllCars();
        Console.continueOnEnter();
        userScreen.display();
    }
}
