package models;

import services.CarService;

import java.util.ArrayList;
import java.util.List;

public class User extends Account {
    // ====================== Fields ======================
    private List<Car> rentedCars = new ArrayList<>();

    // ====================== Constructors ======================
    public User() {}

    public User(String name, String phoneNumber, String email, String password) {
        super(name, phoneNumber, email, password);
    }

    // ====================== Getters ======================


    public List<Car> getRentedCars() {
        return rentedCars;
    }
}
