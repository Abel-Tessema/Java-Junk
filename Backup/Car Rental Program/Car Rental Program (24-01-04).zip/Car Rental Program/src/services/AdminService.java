package services;

public class AdminService {
}
