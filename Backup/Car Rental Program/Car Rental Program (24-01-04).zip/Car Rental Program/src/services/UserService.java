package services;

import models.Car;
import models.Lists;
import models.User;
import utility.Console;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UserService {

    // ====================== Fields ======================
    private static User user;
    private final CarService carService = new CarService();

    // ====================== Log In ======================
    public void logIn(String emailOrPhoneNumber, String password) {
        List<User> users = new ArrayList<>();
        // ToDo: Initialize users from files
        while (true) {
            boolean accessGranted = false;
            for (User aUser : users)
                if (emailOrPhoneNumber.equals(aUser.getEmail()) ||
                        emailOrPhoneNumber.equals(aUser.getPhoneNumber()))
                    if (password.equals(aUser.getPassword())) {
                        user = aUser;
                        accessGranted = true;
                        break;
                    }
            if (accessGranted) break;
            System.out.println("Your email or phone number, and/or password is incorrect. Please try again.");
        }
        System.out.println("Login successful!");
        // ToDo: Write logged in user into a file
        Console.continueOnEnter();
    }

    // ====================== Sign Up ======================
    public void signUp(String name, String phoneNumber, String email, String password) {
        User newUser = new User();

        newUser.setName(name);
        newUser.setPhoneNumber(phoneNumber);
        newUser.setEmail(email);
        newUser.setPassword(password);
        user = newUser;
        // ToDo: Write user to registeredUsers.txt file
        // ToDo: Write user to loggedInUser.txt file
        System.out.println("Signup successful!");
        Console.continueOnEnter();
    }

    // ====================== Book a Car ======================
    public static void bookCar() {
        // Enter ID
        // Enter quantity
        // Enter starting date (dd/mm/yyyy)
        // Enter ending date (dd/mm/yyyy)
        // Recap inputted info and ask for confirmation
        // Booking successful
        // Console.continueOnEnter();
        int carId = (int) Console.readNumber("Enter the ID number of the car you want to rent", 1, Lists.cars.size());
        Car car = Lists.cars.get(carId - 1);
        int carQuantity = (int) Console.readNumber("Enter the quantity of this car you want to rent", 1, car.getQuantityAvailable());
        LocalDate startDate = Console.readDate("Enter the starting date (yyyy-mm-dd)", LocalDate.now(), "Starting date should be no earlier than today. Please try again.");
        LocalDate endDate = Console.readDate("Enter the ending date (yyyy-mm-dd)", startDate, "Ending date should be no earlier than the starting date.");
        // ToDo: Figure out the logic of booking cars and the interplay between two users booking the same car, and write the code here
        car.setQuantityAvailable(car.getQuantityAvailable() - carQuantity);

        System.out.println("Car booked successfully.");
    }

    // ====================== List Rented Cars ======================
    public void listRentedCars() {
        carService.displayCarListHeaders();
        for (Car rentedCar : getUser().getRentedCars())
            carService.displayCar(rentedCar);
    }

    // ====================== Getters ======================
    public User getUser() {
        fetchLoggedInUser();
        return user;
    }

    private void fetchLoggedInUser() {
        // ToDo: Fetch user from loggedInUser.txt file, and assign it to user
    }
}
