package objects;

import accounts.Admin;
import accounts.User;

import java.util.ArrayList;
import java.util.List;

public class Lists {
    public static List<String> carTypes = new ArrayList<>();
    public static List<String> carBrands = new ArrayList<>();
    public static List<User> users = new ArrayList<>();
    public static List<Admin> admins = new ArrayList<>();
    public static void access() {
    }

    //TODO: Read carTypes, carBrands, and users from files and add them to their respective lists.
}
