package objects;

public class Car {
    private int id;
    private String brand;
    private String model;
    private String type;
    private String color;
    private int year;
    private int quantityAvailable;
    private double baseRate;

    // ====================== Constructors ======================

    public Car() {}

    public Car(int id, String brand, String model, String type, String color, int year, int quantityAvailable, double baseRate) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.type = type;
        this.color = color;
        this.year = year;
        this.quantityAvailable = quantityAvailable;
        this.baseRate = baseRate;
    }
    // ====================== Listing ======================
    public static void listAllCars() {}
    public static void displayCar(Car car) {
        System.out.print(car.id);
        System.out.print("\t");
        System.out.print(car.brand);
        System.out.print("\t\t");
        System.out.print(car.model);
        System.out.print("\t\t");
        System.out.print(car.type);
        System.out.print("\t\t");
        System.out.print(car.color);
        System.out.print("\t\t");
        System.out.print(car.year);
        System.out.print("\t\t");
        System.out.print(car.quantityAvailable);
        System.out.print("\t\t\t\t\t");
        System.out.println(car.baseRate);
    }
    public static void listCarsByBrand() {}

    public static void listCarsByType() {}

    public static void listCarsByYear() {}

    public static void searchCar() {}
}
