package operations;

import accounts.User;
import objects.Lists;

import java.util.Scanner;

public class UserOperation {

    // ====================== Private Fields ======================
    private static final Scanner scanner = new Scanner(System.in);
    private static String emailOrPhoneNumber;
    private static boolean emailOrPhoneNumberFound = false;
    private static String password;
    private static String correctPassword = null;
    private static String userName = null;

    // ====================== Public Methods ======================

    // ====================== Log In ======================
    public static void logIn() {
        while (true) {
            System.out.print("Enter your email or phone number: ");
            emailOrPhoneNumber = scanner.nextLine();
            for (int i = 0; i < Lists.users.size(); i++)
                if (emailOrPhoneNumber.equals(Lists.users.get(i).getEmail()) ||
                    emailOrPhoneNumber.equals(Lists.users.get(i).getPhoneNumber())) {
                        userName = Lists.users.get(i).getName();
                        correctPassword = Lists.users.get(i).getPassword();
                        emailOrPhoneNumberFound = true;
                        break;
                }
            if (emailOrPhoneNumberFound) break;
            System.out.println("There is no account with such email or phone number. Please try again.");
        }
        while (true) {
            System.out.print("Enter your password: ");
            password = scanner.nextLine();
            if (password.equals(correctPassword)) break;
            System.out.println("The entered password is incorrect. Please try again.");
        }
    }

    // ====================== Sign Up ======================
    public static void signUp() {
        User user = new User();
        user.setName("Enter your full name");
        user.setPhoneNumber("Enter your phone number");
        user.setEmail("Enter your email address");
        user.setPassword("Enter your password");
        user.confirmPassword("Confirm your password");
    }

    // ====================== Book a Car ======================
    public static void bookCar() {
        // Enter ID
        // Enter quantity
        // Enter starting date (dd/mm/yyyy)
        // Enter ending date (dd/mm/yyyy)
        // Recap inputted info and ask for confirmation
        // Booking successful
        // Console.continueOnEnter();
    }

    // ====================== Getters ======================
    public static String getUserName() {
        return userName;
    }
}
