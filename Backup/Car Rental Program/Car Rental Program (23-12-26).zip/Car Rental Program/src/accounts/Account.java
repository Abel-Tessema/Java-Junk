package accounts;

import utility.Console;
import java.util.Scanner;
import java.util.regex.Pattern;

public abstract class Account {
    // ====================== Fields ======================
    protected String name;
    protected String phoneNumber;
    protected String email;
    protected String password;

    // ====================== Constructors ======================
    public Account() {}
    public Account(String name, String phoneNumber, String email, String password) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
    }
    // ====================== Patterns for the Fields ======================
    public static final Pattern namePattern = Pattern.compile("[A-z]{1,25} [A-z]{1,25}");
    public static final Pattern phoneNumberPattern = Pattern.compile("0[79][0-9]{8}");
    public static final Pattern emailPattern = Pattern.compile("[A-z0-9_]{1,50}@[A-z]{1,10}.com");
    public static final Pattern passwordPattern = Pattern.compile("[!-~]{8,25}");

    // ====================== Getters ======================
    public String getName() {
        return name;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }

    // ====================== Setters ======================
    public void setName(String prompt) {
        this.name = Console.readText(prompt, namePattern, "Please enter your full name with the correct format (e.g. John Doe).");
    }
    public void setPhoneNumber(String prompt) {
        this.phoneNumber = Console.readText(prompt, phoneNumberPattern, "Please enter your phone number with the correct format (09/07xxxxxxxx).");
    }
    public void setEmail(String prompt) {
        this.email = Console.readText(prompt, emailPattern, "Please enter your email address with the correct format (e.g. janedoe@gmail.com).");
    }
    public void setPassword(String prompt) {
        this.password = Console.readText(prompt, passwordPattern, "Your password should contain only the English alphabet letters, numbers, and/or symbols, and should be from 8 to 25 characters long.");
    }
    public void confirmPassword(String prompt) {
        String input;
        while (true) {
            System.out.print(prompt + ": ");
            input = new Scanner(System.in).nextLine();
            if (password.equals(input)) break;
            System.out.println("The confirmed password doesn't match the original one. Please try again.");
        }
    }
}
