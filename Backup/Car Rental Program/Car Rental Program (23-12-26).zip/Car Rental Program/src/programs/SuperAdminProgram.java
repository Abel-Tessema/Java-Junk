package programs;

public class SuperAdminProgram {
    public static void main(String[] args) {

    }
}
