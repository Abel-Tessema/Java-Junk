package programs;

import accounts.Account;
import accounts.Admin;
import accounts.SuperAdmin;
import accounts.User;
import menus.UserMenu;
import objects.Car;
import operations.UserOperation;
import utility.Console;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserProgram {
    public static void main(String[] args) {
        Console.readNumber("Enter number", 1, 5);
//        Car car = new Car(1, "Mercedes-Benz", "SLR-McLaren", "Coupe", "Yellow", 2012, 5, 50.00);
//        System.out.println("ID\tBrand\t\t\t\tModel\t\t\tType\t\tColor\t\tYear\t\tQuantity Available\tBase Rate");
//        Car.displayCar(car);
    }
}