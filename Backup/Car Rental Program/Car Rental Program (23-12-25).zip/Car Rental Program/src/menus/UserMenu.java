package menus;

import accounts.SuperAdmin;
import objects.Car;
import operations.UserOperation;
import utility.Console;

import java.time.LocalDateTime;

public class UserMenu {
    private static String userName;
    public static void welcomeMenu() {
        System.out.println("Welcome to " + SuperAdmin.getCompanyName() + ".");
        System.out.println("What would you like to do?");
        System.out.println("1) Log in");
        System.out.println("2) Sign up");
        System.out.println("3) FAQ");
        System.out.println("4) Exit");
    }

    public static void loginMenu() {
        System.out.println("Welcome Screen > Log In");
        System.out.println("Enter your credentials to log in.");
        userName = UserOperation.logIn();
        System.out.println("Login successful!");
        System.out.println();
        Console.continueOnEnter();
    }

    public static void signupMenu() {
        System.out.println("Welcome Screen > Sign Up");
        System.out.println("Enter your credentials to sign up.");
        UserOperation.signUp();
        System.out.println("Signup successful!");
        System.out.println();
        Console.continueOnEnter();
    }

    public static void faq() {}

    public static void userMainMenu() {
        System.out.println("Welcome Screen > Log In > User Main Menu");
        int currentHour = LocalDateTime.now().getHour();
        if (currentHour >= 6 && currentHour < 12)
            System.out.print("Good morning, ");
        else if (currentHour >= 12 && currentHour < 18)
            System.out.print("Good afternoon, ");
        else
            System.out.print("Good evening, ");
        System.out.println(userName + ".");
        System.out.println("What would you like to do?");
        System.out.println("1) Book a car");
        System.out.println("2) See the list of all cars");
        System.out.println("3) Search for a car");
        System.out.println("4) List all cars you've rented");
        System.out.println("5) Edit your profile");
        System.out.println("6) FAQ");
        System.out.println("7) Log out");
    }

    public static void bookCarMenu() {
        System.out.println("... > User Main Menu > Book a Car");
        System.out.println("How you would like to select a car?");
        System.out.println("1) List all cars and then select");
        System.out.println("2) List cars with filter");
        System.out.println("3) Go back");
        System.out.println("4) Main Menu");
    }

    public static void carListMenu() {
        System.out.println("... > User Main Menu > List All Cars");
        Car.listAllCars();
        System.out.println();
        Console.continueOnEnter();
    }

    public static void searchCarMenu() {
        System.out.println("... > User Main Menu > Search Car");
        System.out.println("How would you like to search the car?");
        System.out.println("1) Search by brand");
        System.out.println("2) Search by model");
        System.out.println("3) Search by type");
        System.out.println("4) Search by year");
        System.out.println("5) Go back");
    }

    public static void listAllRentedCarsMenu() {
        System.out.println("... > User Main Menu > List Rented Cars");
        System.out.println("Here are the cars you're currently renting:");
    }

    public static void editAccountMenu() {
        System.out.println("... > User Main Menu > Edit Account");
        System.out.println("What would you like to change?");
        System.out.println("1) Your name");
        System.out.println("2) Your phone number");
        System.out.println("3) Your email address");
        System.out.println("4) Your password");
        System.out.println("5) Go back");
    }

    public static void logoutMenu() {
        System.out.println("... > User Main Menu > Log Out");
        System.out.println("Are you sure you want to log out?");
        System.out.println("1) Yes");
        System.out.println("2) No");
    }

    public static void listAllCarsAndSelectMenu() {
        System.out.println("... > Book a Car > List All and Select");
        Car.listAllCars();
        System.out.println();
        System.out.print("Enter the ID number of the car you want to book: ");
    }

    public static void listCarsWithFilterMenu() {
        System.out.println("... > Book a Car > List with Filter");
        System.out.println("Which filter do you choose?");
        System.out.println("1) Brand");
        System.out.println("2) Type");
        System.out.println("3) Year");
        System.out.println("4) Go back");
        System.out.println("5) Return to main menu");
    }
}
