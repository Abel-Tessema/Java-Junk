package menus;

public class AdminMenu {
}
