package menus;

public class SuperAdminMenu {
}
