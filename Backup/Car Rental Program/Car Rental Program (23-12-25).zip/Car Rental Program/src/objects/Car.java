package objects;

import java.awt.*;

public class Car {
    private String brand;
    private String model;
    private String type;
    private Color color;
    private int year;
    private int quantityAvailable;
    private double baseRate;

    public static void listAllCars() {}

    public static void searchCar() {}
}
