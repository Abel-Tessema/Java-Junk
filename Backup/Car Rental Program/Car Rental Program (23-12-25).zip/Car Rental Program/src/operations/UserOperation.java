package operations;

import accounts.User;
import objects.Lists;
import utility.Console;

import java.util.Scanner;

public class UserOperation {
    public static String logIn() {
        Scanner scanner = new Scanner(System.in);

        String emailOrPhoneNumber;
        boolean emailOrPhoneNumberFound = false;
        String password;
        String correctPassword = null;
        String userName = null;
        while (true) {
            System.out.print("Enter your email or phone number: ");
            emailOrPhoneNumber = scanner.nextLine();
            for (int i = 0; i < Lists.users.size(); i++)
                if (emailOrPhoneNumber.equals(Lists.users.get(i).getEmail()) ||
                    emailOrPhoneNumber.equals(Lists.users.get(i).getPhoneNumber())) {
                        userName = Lists.users.get(i).getName();
                        correctPassword = Lists.users.get(i).getPassword();
                        emailOrPhoneNumberFound = true;
                        break;
                }
            if (emailOrPhoneNumberFound) break;
            System.out.println("There is no account with such email or phone number. Please try again.");
        }
        while (true) {
            System.out.print("Enter your password: ");
            password = scanner.nextLine();
            if (password.equals(correctPassword)) break;
            System.out.println("The entered password is incorrect. Please try again.");
        }
        return userName;
    }

    public static void signUp() {
        User user = new User();
        user.setName("Enter your full name");
        user.setPhoneNumber("Enter your phone number");
        user.setEmail("Enter your email address");
        user.setPassword("Enter your password");
        user.confirmPassword("Confirm your password");
    }
}
