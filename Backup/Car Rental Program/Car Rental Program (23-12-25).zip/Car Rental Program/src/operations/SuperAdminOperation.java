package operations;

public class SuperAdminOperation {
}
