package operations;

public class AdminOperation {
}
