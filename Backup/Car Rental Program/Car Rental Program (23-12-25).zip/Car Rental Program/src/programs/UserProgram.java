package programs;

import accounts.Account;
import accounts.Admin;
import accounts.SuperAdmin;
import accounts.User;
import operations.UserOperation;

import java.io.Console;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserProgram {
    public static void main(String[] args) throws IOException {
        UserOperation.signUp();
    }
}