package utility;

public class Directory {
    public static String DatabaseDirectory = "database/";
    public static String TableDirectory = DatabaseDirectory + "table/";
    public static String SchemaDirectory = DatabaseDirectory + "schema/";
    public static String SchemaIdsPath = SchemaDirectory + "ids";

}
