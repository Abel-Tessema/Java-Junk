package screen_managers;

public interface AdminScreenManager {
}
