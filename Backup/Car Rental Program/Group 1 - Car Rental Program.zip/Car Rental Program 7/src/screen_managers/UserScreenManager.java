package screen_managers;

public interface UserScreenManager {
    void switchScreen(String screenName);
}
