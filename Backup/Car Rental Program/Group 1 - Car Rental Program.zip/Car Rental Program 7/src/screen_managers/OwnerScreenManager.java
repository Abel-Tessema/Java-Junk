package screen_managers;

public interface OwnerScreenManager {
    void switchScreen(String screenName);
}
