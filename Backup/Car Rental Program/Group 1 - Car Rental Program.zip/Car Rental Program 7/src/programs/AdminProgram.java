package programs;

public abstract class AdminProgram {
    public static void main(String[] args) {
        System.out.println("Yahallo!");
    }
}
