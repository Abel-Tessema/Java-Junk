package file_manager.documentations;

public class Constant {
    public static String _DatabaseDirectory = "database/";
    public static String _TableDirectory = _DatabaseDirectory + "table/";
    public static String _SchemaDirectory = _DatabaseDirectory + "schema/";
    public static String _SchemaIdsPath = _SchemaDirectory + "ids";
}
