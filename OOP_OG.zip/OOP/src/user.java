public class user {

    public static void main(String[] args){

        String cf="[course1a, course1b,course1c,course1d,course1e,course1f]";
    }


}
